---
name: Nocturnal Botanical
colors:
  surface: '#141313'
  surface-dim: '#141313'
  surface-bright: '#3a3938'
  surface-container-lowest: '#0e0e0e'
  surface-container-low: '#1c1b1b'
  surface-container: '#201f1f'
  surface-container-high: '#2a2a29'
  surface-container-highest: '#353534'
  on-surface: '#e5e2e0'
  on-surface-variant: '#c6c7c1'
  inverse-surface: '#e5e2e0'
  inverse-on-surface: '#313030'
  outline: '#8f918c'
  outline-variant: '#454843'
  surface-tint: '#c6c7c2'
  primary: '#c6c7c2'
  on-primary: '#2f312d'
  primary-container: '#121411'
  on-primary-container: '#7d7f7a'
  inverse-primary: '#5d5f5b'
  secondary: '#b7cdaf'
  on-secondary: '#233520'
  secondary-container: '#394c35'
  on-secondary-container: '#a6bb9e'
  tertiary: '#bbccaa'
  on-tertiary: '#27341d'
  tertiary-container: '#0b1704'
  on-tertiary-container: '#748366'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#e3e3dd'
  primary-fixed-dim: '#c6c7c2'
  on-primary-fixed: '#1a1c19'
  on-primary-fixed-variant: '#464743'
  secondary-fixed: '#d3e9ca'
  secondary-fixed-dim: '#b7cdaf'
  on-secondary-fixed: '#0f1f0c'
  on-secondary-fixed-variant: '#394c35'
  tertiary-fixed: '#d7e8c5'
  tertiary-fixed-dim: '#bbccaa'
  on-tertiary-fixed: '#121f09'
  on-tertiary-fixed-variant: '#3d4b31'
  background: '#141313'
  on-background: '#e5e2e0'
  surface-variant: '#353534'
typography:
  h1:
    fontFamily: Newsreader
    fontSize: 48px
    fontWeight: '600'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  h2:
    fontFamily: Newsreader
    fontSize: 32px
    fontWeight: '500'
    lineHeight: '1.2'
    letterSpacing: -0.01em
  h3:
    fontFamily: Newsreader
    fontSize: 24px
    fontWeight: '500'
    lineHeight: '1.3'
    letterSpacing: '0'
  body-lg:
    fontFamily: Newsreader
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
    letterSpacing: '0'
  body-md:
    fontFamily: Newsreader
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
    letterSpacing: '0'
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: '1.0'
    letterSpacing: 0.05em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  base: 8px
  xs: 4px
  sm: 12px
  md: 24px
  lg: 48px
  xl: 80px
  container-max: 1120px
  gutter: 24px
---

## Brand & Style

This design system embodies a "Midnight Conservatory" aesthetic—an evolution of botanical minimalism optimized for deep immersion. The brand personality is intellectual, serene, and premium, targeting users who value focused reading experiences and high-end editorial content. 

The style utilizes **Minimalism** with a heavy emphasis on **Tonal Layering**. By eschewing harsh true-blacks in favor of organic, desaturated forest tones, the UI evokes a sense of quiet luxury. The emotional response should be one of calm sophistication, akin to reading a rare book in a dimly lit library. High-contrast typography ensures that despite the dark environment, information remains the protagonist.

## Colors

The palette is anchored by the primary surface color, **Forest Black (#121411)**, which provides a deep, non-fatiguing base. 

- **Primary & Secondary:** Rich mossy greens (#4A5D45) serve as structural accents, while muted sage (#8A9A7B) is used for interactive states and highlights.
- **Neutrals:** Text utilizes an Off-White (#F2F2F2) for maximum readability against the dark background. Secondary information is rendered in Soft Grey (#A0A59A) to maintain visual hierarchy.
- **Accents:** A brighter sage (#A3B18A) is reserved for critical call-to-actions and active indications, ensuring they "pop" against the desaturated surroundings.

## Typography

This design system relies heavily on the **Newsreader** serif font to establish its editorial authority. Headlines feature tighter tracking and organic weight distributions to mimic high-end print media. 

For functional elements, **Inter** is introduced as a utility typeface for labels and small metadata to ensure legibility where serifs might become cluttered. Body text utilizes generous line heights (1.6) to prevent "rivers" of text and to accommodate the high-contrast color pairing, making long-form reading effortless in dark environments.

## Layout & Spacing

The design system employs a **Fixed Grid** model for editorial content and a **Fluid Layout** for functional dashboards. The central content column is constrained to 1120px to maintain optimal line lengths for the Newsreader typeface.

Spacing follows an 8px rhythmic scale. Margins are intentionally generous (48px+) to create "breathable" dark space, reinforcing the minimalist botanical philosophy. Gutters are kept at a consistent 24px to ensure distinct separation between cards and imagery without breaking the flow of the page.

## Elevation & Depth

In this dark mode environment, depth is communicated through **Tonal Layers** and **Subtle Inner Glows** rather than traditional drop shadows.

1.  **Level 0 (Base):** Forest Black (#121411).
2.  **Level 1 (Cards/Containers):** Surface Variant (#1C1F1A). These surfaces should feature a 1px border in a slightly lighter green-grey (#2D3129) to define edges.
3.  **Level 2 (Popovers/Modals):** A slightly lighter tint of the surface variant with a very soft, diffused shadow (0px 10px 30px rgba(0,0,0,0.5)).

Avoid heavy blurs; instead, use slight shifts in color value to indicate "rising" from the background.

## Shapes

The design system utilizes **Soft (0.25rem)** roundedness. This subtle curvature bridges the gap between the organic botanical theme and the structured, intellectual serif typography. 

- **Standard Elements:** 4px (0.25rem) corner radius for buttons and input fields.
- **Large Containers:** 8px (0.5rem) corner radius for cards and main content areas.
- **Imagery:** Should remain sharp or use the 4px radius to maintain the "editorial photograph" feel.

## Components

- **Buttons:** Primary buttons use a solid Moss Green (#4A5D45) with Off-White text. Secondary buttons use a ghost style with a 1px Sage border. Interactive states should involve a subtle brightness increase rather than a color shift.
- **Cards:** Use the Surface Variant (#1C1F1A) with a 1px stroke. Avoid heavy shadows. Ensure image overlays have a 20% Forest Black tint to maintain text contrast.
- **Inputs:** Fields are dark-filled (#1C1F1A) with a bottom-only border or a very subtle 4-sided stroke. Focus states are indicated by a Sage (#8A9A7B) glow.
- **Chips:** Small, pill-shaped markers with low-opacity Sage backgrounds and high-contrast Sage text.
- **Lists:** Separated by thin 1px dividers (#2D3129). Use Newsreader for list items to maintain the literary tone.
- **Featured Quotes:** A specific component for this system—large Newsreader Italic text with a Moss Green vertical accent bar on the left.