# Progressive Web App (PWA) Implementation Guide

To turn your "Verdant Care" designs into a deployable PWA for your iPhone, follow these steps.

## 1. The Web App Manifest
Create a file named `manifest.json` in your root directory. This tells the browser how your app should behave when installed.

```json
{
  "name": "Verdant Care",
  "short_name": "Verdant",
  "start_url": "/index.html",
  "display": "standalone",
  "background_color": "#fcf9f4",
  "theme_color": "#2D4F1E",
  "icons": [
    {
      "src": "icon-192.png",
      "sizes": "192x192",
      "type": "image/png"
    },
    {
      "src": "icon-512.png",
      "sizes": "512x512",
      "type": "image/png"
    }
  ]
}
```

## 2. iOS Specific Meta Tags
Apple requires specific tags in the `<head>` of your HTML (I will add these to your screens):
- `apple-mobile-web-app-capable`: Enables full-screen mode.
- `apple-mobile-web-app-status-bar-style`: Sets the status bar color.
- `apple-touch-icon`: Defines the home screen icon.

## 3. Service Worker
To make it work offline and load instantly, you need a `service-worker.js`:

```javascript
const CACHE_NAME = 'verdant-care-v1';
const ASSETS = [
  '/',
  '/index.html',
  '/styles.css',
  '/manifest.json'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(ASSETS))
  );
});

self.addEventListener('fetch', (event) => {
  event.respondWith(
    caches.match(event.request).then((response) => response || fetch(event.request))
  );
});
```

## 4. Deployment
1. Host these files on a secure server (HTTPS is required for PWAs).
2. Open the URL in Safari on your iPhone.
3. Tap **Share** > **Add to Home Screen**.
