---
name: Botanical Minimalist
colors:
  surface: '#fcf9f4'
  surface-dim: '#dcdad5'
  surface-bright: '#fcf9f4'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f6f3ee'
  surface-container: '#f0ede8'
  surface-container-high: '#ebe8e3'
  surface-container-highest: '#e5e2dd'
  on-surface: '#1c1c19'
  on-surface-variant: '#43493e'
  inverse-surface: '#31302d'
  inverse-on-surface: '#f3f0eb'
  outline: '#73796d'
  outline-variant: '#c3c8bb'
  surface-tint: '#446733'
  primary: '#173809'
  on-primary: '#ffffff'
  primary-container: '#2d4f1e'
  on-primary-container: '#98c083'
  inverse-primary: '#a9d293'
  secondary: '#506445'
  on-secondary: '#ffffff'
  secondary-container: '#d2eac3'
  on-secondary-container: '#566a4b'
  tertiary: '#55210a'
  on-tertiary: '#ffffff'
  tertiary-container: '#71361e'
  on-tertiary-container: '#f4a182'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#c5efad'
  primary-fixed-dim: '#a9d293'
  on-primary-fixed: '#062100'
  on-primary-fixed-variant: '#2d4f1e'
  secondary-fixed: '#d2eac3'
  secondary-fixed-dim: '#b6cda8'
  on-secondary-fixed: '#0e2008'
  on-secondary-fixed-variant: '#394c2f'
  tertiary-fixed: '#ffdbce'
  tertiary-fixed-dim: '#ffb59a'
  on-tertiary-fixed: '#380d00'
  on-tertiary-fixed-variant: '#71361e'
  background: '#fcf9f4'
  on-background: '#1c1c19'
  surface-variant: '#e5e2dd'
typography:
  h1:
    fontFamily: Newsreader
    fontSize: 40px
    fontWeight: '600'
    lineHeight: '1.2'
  h2:
    fontFamily: Newsreader
    fontSize: 32px
    fontWeight: '500'
    lineHeight: '1.3'
  h3:
    fontFamily: Newsreader
    fontSize: 24px
    fontWeight: '500'
    lineHeight: '1.4'
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: 0.02em
  caption:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '500'
    lineHeight: '1.2'
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  xs: 4px
  sm: 12px
  md: 24px
  lg: 40px
  xl: 64px
  container-margin: 20px
  gutter: 16px
---

## Brand & Style
This design system is built to evoke a sense of tranquility, growth, and organized nurturing. The brand personality is "The Expert Gardener"—someone who is knowledgeable and professional, yet warm and deeply connected to nature. 

The visual style follows a **Modern Minimalist** approach with organic influences. It prioritizes clarity and breathability, using high-value whites and soft earth tones to ensure the vibrant greens of plant photography remain the focal point. By combining crisp layouts with soft, tactile elements, the UI feels both high-end and approachable, moving away from cold corporate tech toward a more restorative, "zen" digital environment.

## Colors
The palette is rooted in a naturalistic hierarchy. The primary **Forest Green** provides authority and depth for text and key actions. **Sage** and **Mint** function as supportive tones for backgrounds and success states, creating a lush, layered green experience. 

**Terracotta** is used sparingly as a functional accent for calls-to-action or notifications, mimicking the warmth of clay pots. The neutral **Sand** and **White** tones replace harsh greys to maintain a soft, organic warmth throughout the interface.

## Typography
The typography strategy relies on a sophisticated "Editorial meets Tech" pairing. **Newsreader** is utilized for headlines to provide a literary, botanical journal aesthetic that feels premium and established. 

For all functional and body text, **Plus Jakarta Sans** provides a friendly, contemporary counterpoint. Its soft curves and open counters ensure high legibility even at small sizes on mobile devices. Use generous line heights (1.6x) for body copy to enhance the "calming" feel of the design system.

## Layout & Spacing
This design system employs a **Fluid Grid** model based on an 8px rhythmic scale. The layout philosophy is "Maximum Breathing Room"—white space is treated as a core design element rather than "empty" space.

On mobile, use a 4-column grid with 20px side margins. On tablet and desktop, scale to a 12-column grid. Components should use `md` (24px) or `lg` (40px) padding to avoid visual clutter. Grouped elements should be separated by clear, consistent vertical rhythms to guide the eye effortlessly through plant care schedules or diagnostic data.

## Elevation & Depth
Depth is conveyed through **Ambient Shadows** and **Tonal Layering**. Avoid high-contrast black shadows; instead, use soft, diffused shadows with a slight primary-color tint (e.g., a deep forest green shadow at 4-8% opacity).

Surface levels are established by layering:
- **Level 0 (Base):** Crisp White or Sand background.
- **Level 1 (Cards):** White surfaces with subtle, wide-spread shadows.
- **Level 2 (Modals/Popovers):** White surfaces with slightly tighter, more pronounced shadows to indicate direct interaction.

Backdrop blurs may be used sparingly on navigation bars to maintain a sense of glass-like transparency without sacrificing the clean, botanical aesthetic.

## Shapes
The shape language is defined by "Natural Curvature." There are no sharp 90-degree angles in the design system. 

The standard radius is **0.5rem (8px)** for input fields and small cards, while larger container elements and buttons utilize **1rem (16px)** or **1.5rem (24px)** to feel more organic and "pebble-like." This softness reflects the organic forms found in nature, making the digital experience feel more tactile and less rigid.

## Components

### Buttons
Primary buttons should be Forest Green with white text, featuring 24px (xl) rounded corners. Secondary buttons should use the Mint accent background with Forest Green text. All buttons should have a subtle "lift" effect on hover/active states.

### Chips & Tags
Use chips for plant categories (e.g., "Succulent", "Low Light"). These should have pill-shaped corners and use soft Sage or Sand backgrounds with dark green labels.

### Cards
Cards are the primary vessel for plant profiles. They should feature a crisp white background, a Level 1 ambient shadow, and a 16px corner radius. Image containers within cards should have a matching radius or be slightly inset.

### Inputs
Search bars and form fields use a 1px border in a muted Sage color or a solid Sand background with no border. Focus states transition the border to Forest Green with a soft outer glow.

### Progress & Health Indicators
Use thin-line "Growth Rings" or horizontal bars with rounded caps. The Mint-to-Forest gradient is used for healthy status, while Terracotta indicates an "Action Required" or "Dry Soil" state.

### Icons
Icons must be thin-line (1.5px stroke), nature-inspired, and never filled. Terminate line ends with rounded caps to match the overall shape language.